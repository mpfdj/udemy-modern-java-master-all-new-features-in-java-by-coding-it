package com.modulethree.client;

import org.junit.jupiter.api.Test;

class Module1ClientTest {

    @Test
    void retrieveData() {
    }
}