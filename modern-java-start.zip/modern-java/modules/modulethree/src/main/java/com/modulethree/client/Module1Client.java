package com.modulethree.client;


public class Module1Client {

//    private final Module1Service module1Service;
//
//    public Module1Client(Module1Service module1Service) {
//        this.module1Service = module1Service;
//    }
//
//    public Module1DTO retrieveData(){
//        return module1Service.retrieveData();
//    }
}
