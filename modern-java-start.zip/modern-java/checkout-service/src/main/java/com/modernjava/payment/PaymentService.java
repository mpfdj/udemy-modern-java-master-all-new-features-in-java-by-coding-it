package com.modernjava.payment;

import com.modernjava.domain.*;
import com.modernjava.payment.*;

public class PaymentService {

    public PaymentResponse makePaymentv2(OrderDetails orderDetails) {

        //implement a payment gateway that can handle the different kinds of payment.
        return PaymentResponse.SUCCESS;
    }
}
