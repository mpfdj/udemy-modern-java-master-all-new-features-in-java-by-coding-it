package com.modernjava.sealed;

public class Car extends Vehicle {

}
