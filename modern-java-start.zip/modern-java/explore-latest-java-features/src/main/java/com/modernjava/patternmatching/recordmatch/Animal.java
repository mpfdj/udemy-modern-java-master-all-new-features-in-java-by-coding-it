package com.modernjava.patternmatching.recordmatch;

public sealed interface Animal permits Cat, Dog {
}
