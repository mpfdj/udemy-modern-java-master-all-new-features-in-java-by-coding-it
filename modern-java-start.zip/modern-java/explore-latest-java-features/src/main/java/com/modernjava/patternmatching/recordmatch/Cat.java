package com.modernjava.patternmatching.recordmatch;

public record Cat(String name,
                  String color) implements Animal {
}
