package com.modernjava.sealed;

public class Dog extends Vehicle{
}
