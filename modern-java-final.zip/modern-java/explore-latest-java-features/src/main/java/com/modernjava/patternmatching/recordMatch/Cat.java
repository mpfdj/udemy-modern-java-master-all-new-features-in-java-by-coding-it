package com.modernjava.patternmatching.recordMatch;

public record Cat(String name,
                  String color) implements Animal {
}
