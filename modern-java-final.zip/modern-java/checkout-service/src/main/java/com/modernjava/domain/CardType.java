package com.modernjava.domain;

public enum CardType {
    CREDIT,
    DEBIT,
    REWARDS
}
