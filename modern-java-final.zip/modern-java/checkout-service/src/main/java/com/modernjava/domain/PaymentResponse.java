package com.modernjava.domain;

public enum PaymentResponse {

    SUCCESS,
    FAILURE
}
