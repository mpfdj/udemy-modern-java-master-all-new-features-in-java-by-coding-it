rootProject.name = "modern-java"
include("modules")
include("modules:moduleone")
include("modules:moduletwo")
include("modules:modulethree")
include("modules:modulefour")
include("explore-latest-java-features")
include("checkout-service")
